package com.mtftp.app

import org.junit.Assert.assertTrue
import org.junit.Test

class LoginValidatorTest {

    @Test
    fun `accepts mt3000 to mt4000 inclusive with mt1234`() {
        assertTrue(LoginValidator.validate("mt3000", "mt1234") is LoginValidator.Result.Success)
        assertTrue(LoginValidator.validate("mt3500", "mt1234") is LoginValidator.Result.Success)
        assertTrue(LoginValidator.validate("mt4000", "mt1234") is LoginValidator.Result.Success)
    }

    @Test
    fun `rejects out of range usernames`() {
        assertTrue(LoginValidator.validate("mt2999", "mt1234") is LoginValidator.Result.Error)
        assertTrue(LoginValidator.validate("mt4001", "mt1234") is LoginValidator.Result.Error)
        assertTrue(LoginValidator.validate("MT3000", "mt1234") is LoginValidator.Result.Error)
        assertTrue(LoginValidator.validate("admin", "mt1234") is LoginValidator.Result.Error)
    }

    @Test
    fun `rejects incorrect or uppercase passwords`() {
        assertTrue(LoginValidator.validate("mt3000", "MT1234") is LoginValidator.Result.Error)
        assertTrue(LoginValidator.validate("mt3000", "wrong") is LoginValidator.Result.Error)
        assertTrue(LoginValidator.validate("mt3000", "") is LoginValidator.Result.Error)
    }
}
