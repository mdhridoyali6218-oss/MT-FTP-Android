package com.mtftp.app

object LoginValidator {

    private val USERNAME_REGEX = Regex("^mt(\\d{4})$")
    private const val MIN_ACCOUNT_NUMBER = 3000
    private const val MAX_ACCOUNT_NUMBER = 4000
    private const val REQUIRED_PASSWORD = "mt1234"

    sealed class Result {
        data class Success(val username: String) : Result()
        data class Error(val message: String) : Result()
    }

    fun validate(rawUsername: String, rawPassword: String): Result {
        val username = rawUsername.trim()
        if (username.isEmpty()) {
            return Result.Error("Please enter your username (mt3000 to mt4000).")
        }

        val match = USERNAME_REGEX.matchEntire(username)
            ?: return Result.Error("Invalid username. Allowed range: mt3000 to mt4000 (lowercase).")

        val accountNumber = match.groupValues[1].toIntOrNull()
            ?: return Result.Error("Invalid username format.")

        if (accountNumber < MIN_ACCOUNT_NUMBER || accountNumber > MAX_ACCOUNT_NUMBER) {
            return Result.Error("Username out of range. Allowed accounts: mt3000 to mt4000.")
        }

        if (rawPassword != REQUIRED_PASSWORD) {
            return Result.Error("Invalid password. Password must be mt1234 (all lowercase).")
        }

        return Result.Success(username)
    }
}
