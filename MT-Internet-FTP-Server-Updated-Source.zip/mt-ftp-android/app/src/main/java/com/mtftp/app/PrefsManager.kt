package com.mtftp.app

import android.content.Context

class PrefsManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED_IN, false)

    fun getUsername(): String = prefs.getString(KEY_USERNAME, "") ?: ""

    fun saveLogin(username: String) {
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_USERNAME, username)
            .commit()
    }

    fun clearLogin() {
        prefs.edit()
            .remove(KEY_IS_LOGGED_IN)
            .remove(KEY_USERNAME)
            .commit()
    }

    companion object {
        private const val PREFS_NAME = "mt_ftp_prefs"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USERNAME = "saved_username"
    }
}
