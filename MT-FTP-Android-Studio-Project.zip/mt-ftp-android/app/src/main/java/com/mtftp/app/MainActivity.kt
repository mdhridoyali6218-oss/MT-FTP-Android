package com.mtftp.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Message
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.mtftp.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefsManager: PrefsManager
    private var hasLoadError = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefsManager = PrefsManager(this)
        if (!prefsManager.isLoggedIn()) {
            redirectToLogin()
            return
        }

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupTopBar()
        setupWebView()
        setupBackNavigation()

        if (savedInstanceState == null) {
            loadServerPage()
        } else {
            binding.webView.restoreState(savedInstanceState)
        }
    }

    private fun setupTopBar() {
        // Strictly display only 172.16.200.201 without http://
        binding.tvAddressBar.text = DISPLAY_HOST
        binding.tvUserBadge.text = prefsManager.getUsername()

        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()) {
                binding.webView.goBack()
            }
        }

        binding.btnRefresh.setOnClickListener {
            loadServerPage()
        }

        binding.btnLogout.setOnClickListener {
            performLogout()
        }

        binding.btnRetry.setOnClickListener {
            loadServerPage()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }

        webView.isFocusable = true
        webView.isFocusableInTouchMode = true

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                // Keep all HTTP/HTTPS navigation strictly inside the embedded WebView.
                // Never open Chrome or any external browser.
                return if (url.startsWith("http://") || url.startsWith("https://")) {
                    false
                } else {
                    true
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                hasLoadError = false
                binding.errorOverlay.visibility = View.GONE
                binding.progressBar.visibility = View.VISIBLE
                binding.tvAddressBar.text = DISPLAY_HOST
                updateBackButtonState()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                binding.progressBar.visibility = View.GONE
                binding.tvAddressBar.text = DISPLAY_HOST
                updateBackButtonState()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    hasLoadError = true
                    binding.progressBar.visibility = View.GONE
                    binding.errorOverlay.visibility = View.VISIBLE
                    binding.btnRetry.requestFocus()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (!hasLoadError) {
                    binding.progressBar.progress = newProgress
                    binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                // Route target="_blank" / window.open() links into the same WebView
                // so external browsers like Chrome are never launched.
                val href = view?.hitTestResult?.extra
                if (!href.isNullOrBlank() && (href.startsWith("http://") || href.startsWith("https://"))) {
                    view.loadUrl(href)
                }
                return false
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::binding.isInitialized && binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    private fun loadServerPage() {
        hasLoadError = false
        binding.errorOverlay.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE
        binding.tvAddressBar.text = DISPLAY_HOST
        binding.webView.loadUrl(SERVER_URL)
    }

    private fun updateBackButtonState() {
        val canGoBack = binding.webView.canGoBack()
        binding.btnBack.isEnabled = canGoBack
        binding.btnBack.alpha = if (canGoBack) 1.0f else 0.4f
    }

    private fun performLogout() {
        prefsManager.clearLogin()
        if (::binding.isInitialized) {
            binding.webView.stopLoading()
            binding.webView.clearHistory()
        }
        redirectToLogin()
    }

    private fun redirectToLogin() {
        val intent = Intent(this, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        finish()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::binding.isInitialized) {
            binding.webView.saveState(outState)
        }
    }

    override fun onDestroy() {
        if (::binding.isInitialized) {
            binding.webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val SERVER_URL = "http://172.16.200.201"
        private const val DISPLAY_HOST = "172.16.200.201"
    }
}
