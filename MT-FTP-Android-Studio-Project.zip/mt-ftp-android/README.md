# MT FTP — Android Phone & Android TV Project

Complete Android Studio project for **MT FTP** supporting Android Phones, Tablets, and Android TV.

## Features Implemented
- **First-Launch Local Login Screen**: Prompts for credentials on first launch.
- **Username Validation**: Allows lowercase usernames `mt3000` through `mt4000` (inclusive).
- **Password Validation**: Requires `mt1234` (all lowercase).
- **Persistent Session**: Saves login state in `SharedPreferences` (`PrefsManager`). Reopening the app goes directly to the server view without asking to log in again.
- **Embedded WebView**: Loads `http://172.16.200.201` directly inside the app with cleartext HTTP permitted via `network_security_config.xml`.
- **Clean Address Bar**: Displays strictly `172.16.200.201` (never shows `http://`).
- **In-App Navigation Lock**: Custom `WebViewClient` and `WebChromeClient` keep all links and `target="_blank"` windows inside the app—Chrome or external browsers are never launched.
- **Logout Control**: Clears saved login credentials and returns immediately to the login screen.
- **Phone & Android TV Ready**: Includes `LEANBACK_LAUNCHER` intent filter, `tv_banner.xml` (320×180), dedicated `layout-television/` layouts with overscan padding, and D-pad focus rings.

---

## How to Build the APK in Android Studio

1. **Open Project**:
   - Launch **Android Studio** (Koala / Ladybug / Meerkat or newer).
   - Select **File → Open** and choose the `mt-ftp-android` folder.
   - Wait for Gradle sync to finish (requires Android SDK 35 and JDK 17).
2. **Build a Debug APK** (for direct sideloading to Phone or Android TV):
   - Top menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   - When the notification appears, click **locate** to open `app/build/outputs/apk/debug/app-debug.apk`.
3. **Build a Signed Release APK**:
   - Top menu: **Build → Generate Signed Bundle / APK...** → select **APK** → **Next**.
   - Choose or create a keystore (`.jks`), enter passwords/alias, select **release** build variant, and click **Create**.
   - Output file: `app/build/outputs/apk/release/app-release.apk`.

## How to Build the APK from Command Line

If Gradle is installed locally:

```bash
cd mt-ftp-android
gradle assembleDebug
```

Or generate the local wrapper once and run it:

```bash
cd mt-ftp-android
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

Install directly via ADB to a connected Android Phone or Android TV:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
